def print_menu():     #Menu display logic
    print("\n Welcome to the Contact Book CLI System! \nLoading contacts from contacts.json... Done!")
    print("\n=========== MENU ================ ")
    print("1. Add Contact")
    print("2. View All Contacts")
    print("3. Remove Contact")
    print("4. Search Contacts")
    print("5. Exit")
    print("=====================================")